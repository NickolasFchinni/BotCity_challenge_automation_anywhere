#!/bin/bash

zip -r "customer_onboarding.zip" * -x "customer_onboarding.zip"